/*
 * This file generated on line 403 of /build/buildd/atlas-3.10.1/build/atlas-base/../..//tune/blas/gemv/mvthgen.c
 */
#ifndef ATLAS_CMVTKERNELS_H
   #define ATLAS_CMVTKERNELS_H

void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900003(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900003_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900002(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900002_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);


#endif /* end guard around atlas_cmvtkernels.h */
