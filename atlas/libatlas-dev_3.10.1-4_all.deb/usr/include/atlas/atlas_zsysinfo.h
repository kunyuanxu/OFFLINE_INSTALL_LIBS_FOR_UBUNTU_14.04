#ifndef ATL_ZSYSINFO_H
   #define ATL_ZSYSINFO_H

#define ATL_NOMULADD
#define ATL_L1elts 2048
#define ATL_fplat  3
#define ATL_lbnreg 9
#define ATL_mmnreg 16
#define ATL_nkflop 746746

#endif
