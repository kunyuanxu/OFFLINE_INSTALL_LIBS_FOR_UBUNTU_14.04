#ifndef ATLAS_CSYR2_H
   #define ATLAS_CSYR2_H
   #define ATL_S2NX 2000
#endif
