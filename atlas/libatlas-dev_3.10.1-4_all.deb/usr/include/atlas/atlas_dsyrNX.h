#ifndef ATLAS_DSYR_H
   #define ATLAS_DSYR_H
   #define ATL_S1NX 0
#endif
