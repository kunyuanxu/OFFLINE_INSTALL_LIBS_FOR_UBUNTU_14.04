#ifndef SXOVER_H
#define SXOVER_H

#define ATL_3NB 180
#define NN_MNK_M 6000
#define NN_MNK_N 6000
#define NN_MNK_MN 36000
#define NN_MNK_K 13500
#define NN_MNK_GE 13824
#define NT_MNK_M 6000
#define NT_MNK_N 6000
#define NT_MNK_MN 36000
#define NT_MNK_K 13500
#define NT_MNK_GE 1000
#define TN_MNK_M 6000
#define TN_MNK_N 6000
#define TN_MNK_MN 36000
#define TN_MNK_K 6298560
#define TN_MNK_GE 1000
#define TT_MNK_M 6000
#define TT_MNK_N 6000
#define TT_MNK_MN 36000
#define TT_MNK_K 13500
#define TT_MNK_GE 1000

#endif
