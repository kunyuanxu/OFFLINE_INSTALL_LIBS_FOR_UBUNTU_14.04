/*
 * This file generated on line 730 of /build/buildd/atlas-3.10.1/build/atlas-base/../..//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_DR1KERNELS_H
   #define ATLAS_DR1KERNELS_H

void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);


#endif /* end guard around atlas_dr1kernels.h */
