#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 180
#define NN_MNK_M 6000
#define NN_MNK_N 6000
#define NN_MNK_MN 36000
#define NN_MNK_K 86640
#define NN_MNK_GE 1000
#define NT_MNK_M 6000
#define NT_MNK_N 6000
#define NT_MNK_MN 36000
#define NT_MNK_K 13500
#define NT_MNK_GE 1000
#define TN_MNK_M 6000
#define TN_MNK_N 6000
#define TN_MNK_MN 36000
#define TN_MNK_K 132540
#define TN_MNK_GE 1000
#define TT_MNK_M 6000
#define TT_MNK_N 6000
#define TT_MNK_MN 36000
#define TT_MNK_K 13500
#define TT_MNK_GE 1000
#define C2R_K 1223

#endif
