#ifndef ATL_CSYSINFO_H
   #define ATL_CSYSINFO_H

#define ATL_NOMULADD
#define ATL_L1elts 1024
#define ATL_fplat  3
#define ATL_lbnreg 9
#define ATL_mmnreg 16
#define ATL_nkflop 747050

#endif
